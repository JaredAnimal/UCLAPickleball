@echo off
setlocal DisableDelayedExpansion
rem Choose a random bright text color on a black background.
set /a "PICKLEBOT_COLOR=%RANDOM% %% 6"
if "%PICKLEBOT_COLOR%"=="0" color 09
if "%PICKLEBOT_COLOR%"=="1" color 0A
if "%PICKLEBOT_COLOR%"=="2" color 0B
if "%PICKLEBOT_COLOR%"=="3" color 0C
if "%PICKLEBOT_COLOR%"=="4" color 0D
if "%PICKLEBOT_COLOR%"=="5" color 0E
title Picklebot Setup
cd /d "%~dp0"
if errorlevel 1 exit /b 1
set "PREVIEW=0"
if /i "%~1"=="/preview" goto preview
goto setup

:setup
echo.
echo Extract all files first and keep this folder somewhere permanent.
echo Run setup under your normal Windows account.
for %%F in (Picklebot.js package.json package-lock.json) do (
    if not exist "%%F" (
        echo ERROR: %%F is missing.
        goto failed
    )
)
call :checknode
if errorlevel 1 goto missingnode
where npm.cmd >nul 2>&1
if errorlevel 1 goto missingnode
echo [1/4] Installing dependencies...
call npm.cmd ci
if errorlevel 1 goto failed
echo [2/4] Installing Playwright Firefox...
node "node_modules\playwright\cli.js" install firefox
if errorlevel 1 goto failed
echo [3/4] Checking Firefox...
node -e "(async()=>{const b=await require('playwright').firefox.launch({headless:true});await b.close();console.log('Firefox check passed.');})().catch(()=>{console.error('Firefox could not start.');process.exit(1);})"
if errorlevel 1 goto failed
echo [4/4] Configuring credentials...
echo Credentials are stored as plain text. Do not share credentials.env.
if exist "credentials.env" goto editcredentials
> "credentials.env" echo LOGIN_USERNAME=
>> "credentials.env" echo LOGIN_PASSWORD=
:editcredentials
echo Enter your own UCLA login, save and close Notepad, then continue here.
echo LOGIN_USERNAME=your_logon_id
echo LOGIN_PASSWORD="your_password"
start /wait "" notepad.exe "%CD%\credentials.env"
pause
call :credentials
if errorlevel 1 goto failed
echo.
echo OPTIONAL DAILY SCHEDULE
echo Choose the reservation hour; the bot starts five minutes earlier.
echo Example: 19 means a 7 PM slot and a 6:55 PM launch.
echo The bot targets three days ahead and may require Duo approval.
echo Windows must use Pacific time. Stay signed in, awake and online.
choice /c YN /n /m "Create a daily schedule? [Y/N]: "
if errorlevel 255 goto failed
if errorlevel 2 goto setupdone
if errorlevel 1 goto createschedule
goto failed

:createschedule
set "PICKLEBOT_SETUP_DIR=%CD%"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; try { if((Get-TimeZone).Id -ne 'Pacific Standard Time'){throw 'Set Windows to Pacific time, then rerun setup.'}; $hour=0; $answer=Read-Host 'Reservation hour, 1-23; 19 means 7 PM'; if(-not [int]::TryParse($answer,[ref]$hour) -or $hour -lt 1 -or $hour -gt 23){throw 'Enter a whole hour from 1 to 23. Midnight is not supported.'}; $identity=[Security.Principal.WindowsIdentity]::GetCurrent(); $name='Picklebot-Daily-'+$identity.User.Value; if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'A daily task already exists. Edit or delete it in Task Scheduler first.'}; $folder=$env:PICKLEBOT_SETUP_DIR; $node=(Get-Command node.exe).Source; $script=Join-Path $folder 'Picklebot.js'; $argument=[char]34+$script+[char]34; $action=New-ScheduledTaskAction -Execute $node -Argument $argument -WorkingDirectory $folder; $time=[datetime]::Today.AddHours($hour).AddMinutes(-5); $trigger=New-ScheduledTaskTrigger -Daily -At $time; $principal=New-ScheduledTaskPrincipal -UserId $identity.Name -LogonType Interactive -RunLevel Limited; $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 15) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries; Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Picklebot daily booking attempt. Requires user signed in and possible Duo approval.' | Out-Null; Write-Host ('Daily launch: '+$time.ToString('HH:mm')+' Pacific.'); Write-Host 'Pause by disabling the Picklebot-Daily task in Task Scheduler.' } catch { Write-Host ('Schedule not created: '+$_.Exception.Message); exit 1 }"
if errorlevel 1 echo Installation completed, but scheduling did not finish.
:setupdone
echo Setup complete. Running basic checks next.
goto test

:test
echo.
echo [1/6] Checking Node.js...
call :checknode
if errorlevel 1 goto missingnode
node --version
echo [2/6] Checking files...
for %%F in (Picklebot.js package.json credentials.env) do (
    if not exist "%%F" (
        echo FAIL: %%F is missing. Run setup first.
        goto failed
    )
)
echo [3/6] Checking syntax and dependencies...
node --check "Picklebot.js"
if errorlevel 1 goto failed
node -e "try{require('playwright');require('dotenv');console.log('PASS: Dependencies available.');}catch{console.error('FAIL: Run setup to install dependencies.');process.exit(1);}"
if errorlevel 1 goto failed
echo [4/6] Checking credential fields...
call :credentials
if errorlevel 1 goto failed
echo [5/6] Checking local time zone...
node -e "const zone=Intl.DateTimeFormat().resolvedOptions().timeZone;console.log('Time zone: '+zone);console.log('Local time: '+new Date().toLocaleString());console.log(zone==='America/Los_Angeles'?'PASS: Pacific time configured.':'WARNING: Set Windows to Pacific time before booking.');"
if errorlevel 1 goto failed
echo [6/6] Checking Firefox and UCLA page access...
echo Browser launch and page access can each take up to 30 seconds.
node -e "(async()=>{let b;try{b=await require('playwright').firefox.launch({headless:true,timeout:30000});console.log('PASS: Firefox launched.');const p=await b.newPage();const r=await p.goto('https://secure.recreation.ucla.edu/booking/02a10035-6fd3-48b1-9a1f-648f6368c09a',{waitUntil:'domcontentloaded',timeout:30000});if(!r||!r.ok())throw new Error('page');console.log('PASS: UCLA page responded.');}catch{console.error('FAIL: Firefox launch or UCLA page access failed. Check internet or rerun setup.');process.exitCode=1;}finally{if(b)await b.close();}})().catch(()=>{console.error('FAIL: Browser test could not finish.');process.exitCode=1;})"
if errorlevel 1 goto failed
echo.
echo BASIC CHECKS PASSED. Review any time-zone warning.
echo Your password, Duo and booking flow were NOT tested.
echo No login or reservation was attempted.
goto power

:preview
set "PREVIEW=1"
:power
echo.
echo Plugged-in settings for the current Windows power plan:
echo   Sleep: Never
echo   Automatic hibernation: Never
echo   Closing the lid: Keep running
echo   Display off: After 5 minutes of inactivity
echo Battery settings are unchanged. Changes persist after reboot.
echo Keep the laptop plugged in, ventilated and signed in.
if "%PREVIEW%"=="1" goto applypower
choice /c YN /n /m "Apply these settings? [Y/N]: "
if errorlevel 255 goto failed
if errorlevel 2 goto done
if errorlevel 1 goto applypower
goto failed
:applypower
call :powercommand /change standby-timeout-ac 0
if errorlevel 1 goto powerfailed
call :powercommand /change hibernate-timeout-ac 0
if errorlevel 1 goto powerfailed
call :powercommand /setacvalueindex SCHEME_CURRENT SUB_BUTTONS 5ca83367-6e45-459f-a27b-476b1d01c936 0
if errorlevel 1 goto powerfailed
call :powercommand /change monitor-timeout-ac 5
if errorlevel 1 goto powerfailed
call :powercommand /setactive SCHEME_CURRENT
if errorlevel 1 goto powerfailed
if "%PREVIEW%"=="1" exit /b 0
echo Power settings applied. Duo approval may still be required.
echo To undo, adjust the current plan in Control Panel - Power Options.
echo Switching plans may change these settings.
echo Test with the lid closed before relying on unattended booking.
goto done

:powercommand
if "%PREVIEW%"=="1" (
    echo PREVIEW: powercfg %*
    exit /b 0
)
powercfg %*
exit /b %errorlevel%

:checknode
where node.exe >nul 2>&1
if errorlevel 1 exit /b 1
node -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)"
exit /b %errorlevel%

:credentials
node -e "try{const c=require('dotenv').parse(require('fs').readFileSync('credentials.env'));if(!c.LOGIN_USERNAME||!c.LOGIN_PASSWORD)throw new Error();console.log('Both credential fields contain values. Login has not been tested.');}catch{console.error('FAIL: Could not read both credential fields. Run setup.');process.exit(1);}"
exit /b %errorlevel%

:missingnode
echo Install Node.js LTS from https://nodejs.org/ with npm and PATH enabled.
echo Close this window and reopen this batch file afterward.
goto failed
:powerfailed
echo A power setting could not be applied. Earlier changes may remain.
echo If access was denied, adjust settings in Control Panel - Power Options.
echo Work or school policies may restrict these settings.
goto failed
:failed
echo The operation stopped. Review the error above.
pause
exit /b 1

:done
echo.
echo Finished. Setup, basic checks and optional power settings are complete.
echo This file does not launch a booking attempt.
pause
exit /b 0

