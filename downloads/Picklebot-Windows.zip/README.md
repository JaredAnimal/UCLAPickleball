**Download and install**

1\. Download and install Node.js LTS from nodejs.org using the default options, including npm and PATH.

2\. Download the Picklebot ZIP and select Extract All.

5\. Double-click SETUP.bat. If Windows reports access denied, right-click that file and select Run as administrator. If it freezes, wait five minutes and rerun it.

6\. When Notepad opens, enter your own login information, save the file, close Notepad, and return to the setup window:

&nbsp;